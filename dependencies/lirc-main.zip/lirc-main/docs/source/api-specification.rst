API Specification
=================

.. automodule:: lirc
   :members:
   :undoc-members:
   :show-inheritance:

