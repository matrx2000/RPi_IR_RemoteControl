from lirc.client import Client
from lirc.connection.lircd_connection import LircdConnection

__version__ = "2.0.2"

__all__ = ["Client", "LircdConnection"]
